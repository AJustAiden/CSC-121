#Aiden Allison
#2/27/2024
#M7PRO object oriented programming
from Functions import *

def main():
    student_reg = get_student_reg()
    menu = display_menu()
    while menu != "5":
        print(menu)
        if menu == "1":
            for item in student_reg: #item is actually a dict
                print(item)
        elif menu == "2":
            locate = input("What class roster do you want to find: ")
            for roster in (display_student_ros(student_reg,locate)):
                print(roster)
        elif menu == "3":
            locate = input("What major do you want to find: ")
            (display_student_major(student_reg,locate))
        elif menu == "4":
            locate = input("What ID do you want to find: ")
            print(display_student_ID(student_reg,locate))
        elif menu == "5":
            print("quitting program....")
        else:
            print("error no number to select menu")
        menu = display_menu()
if __name__ == "__main__":
        main()
