class Student:
    def __init__(self, stuID,firstName,lastName,major,courses):
        self.stuID = stuID
        self.firstName = firstName
        self.lastName = lastName
        self.major = major
        self.courses = courses
        self.email = lastName + stuID[-2:] + "@student.faytechcc.edu"
    def get_email(self):
        self.email = self.lastName + self.stuID[-2:] + "@student.faytechcc.edu"
    def __repr__(self):
        return (f"Student ID:{self.stuID:<7}FirstName:{self.firstName:<20} LastName:{self.lastName:<20} Major:{self.major:<20} Email:{self.email:<20}")
    def modify_id(self):
        new_stu_id = input("Enter a new student id for" +" "+ self.firstName+ " " + self.lastName)
        self.stuID = new_stu_id
        self.get_email()
def get_student_reg():
    student1 = Student("12001", "Janice", "Sopranos", "math", ["CTI-110","CSC-121","Math-111"])
    student2 = Student("12013", 'James', 'Spadling', 'Programming',['ENG211-English', 'PSY101-Intro to Psychology', 'ETH101-Intro to Ethics'])
    student3 = Student("12014", 'John', 'Spadling', 'Psychology',['MAT143-Math', 'ENG111-English', 'CIS115-Intro to Programming', 'CSC121-Python'])
    student4 = Student("12015", 'Rayliee', 'Craston', 'Programming',["MAT143-Math","ENG111-English","CIS115-Intro to Programming","CSC121-Python"])
    student5 = Student("12016", 'Carter', 'Spadling', 'Economics',['MAT243-Math', 'ENG211-English', 'HIS168-Religious History', 'HIS190-Intro to Art History'])
    student6 = Student("12017", 'Brodiey', 'Craston', 'Psychology',['MAT143-Math', 'ENG111-English', 'ETH101-Intro to Ethics', 'BUS121-Market Basics'])
    student7 = Student("12018", 'Craston', 'Caera', 'Economics',['MAT343-Math', 'ENG311-English', 'ETH101-Intro to Ethics', 'EDU201-Adolescent Education'])
    student_list = [student1,student2,student3,student4,student5,student6,student7]
    return student_list
def display_menu():
    print(' MENU')
    print("1)Display student registry")
    print("2)Display course roster")#display all students in a class
    print("3)Display students by major")
    print("4)Display student by ID")
    print("5)Quit")
    selectmenu = input("Menu choice:")
    return selectmenu
def display_student_ros(student_reg,course_class):
    studentsroster = []
    for item in student_reg: #item is actually a dict
        for i in item.courses:
            if i == course_class:
                studentsroster.append(( item.firstName + " " + item.lastName + " has this course," + i))
    for i in studentsroster:
        print(i)
        print("---------------------------") 
    return studentsroster
def display_student_major(student_reg,course_class):
    studentsroster = []
    for item in student_reg: #item is actually a dict
        if item.major == course_class:
            studentsroster.append(( item.firstName + " " + item.lastName + " has this major," + item.major))
    for i in studentsroster:
        print(i)
        print("---------------------------")                         
def display_student_ID(student_reg,ID):
    for item in student_reg: #item is actually a dict
        if item.stuID == ID:
            return( item.firstName + " " + item.lastName + " has this ID," + item.stuID)
