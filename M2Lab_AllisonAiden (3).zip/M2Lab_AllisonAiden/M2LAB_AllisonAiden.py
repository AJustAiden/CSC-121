#Menu basics
#1/13/24
#CSC121 M2lab-Function Review
#Aiden Allison
'''
def getinputs()
    "arrival rate of customers: "
    input rateCustomers
    "The service rate: "
    input serviceRate
    return serviceRate, rateCustomers
def calcWaitTime(Crate,Srate)
    waitTime = 1/(servicerate-ratecustomers) - 1/ratecustomers
    customersLine = rateCustomer/(servicerate-ratecustomers)- ratecustomers/servicerate
    return waitTime, customersLine
def displayresult()
    MinuteWait = expWaitTime*60
    return MinuteWait
def Display_Menu()
    print ("menu")
    print("1)Calculate wait time")
    print("2)Quit")
    Menu choice:
    input selectmenu
def main()
    If selectmenu == "2"
        print("qutting program")
    else
    a,b = getinputs()
    WaitTime,CustomersLine = calcWaitTime(a,b)
    print Avg wait time {displayresult}
'''

import Ffile 
def main():
    if Ffile.display_menu() == "2":
        print("quitting program....")
    else:
        a,b = Ffile.getInputs()
        waitTime,customersLine = Ffile.calcWaitTime(a,b)
        print(f"Avg wait time: {Ffile.displayResult(waitTime):.1f}")
    
if __name__ == "__main__":
        main()
