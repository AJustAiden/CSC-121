def getInputs():
    rateCustomers = int(input("Arrival rate of customers: "))
    serviceRate = float(input("The service rate: "))
    return rateCustomers, serviceRate
def calcWaitTime(Prate, Srate):
    waitTime = float(1/(Srate-Prate) - 1/Srate)
    customersLine = float(Prate/(Srate-Prate)- Prate/Srate)
    return float(waitTime),float(customersLine)
def displayResult(expWaitTime):
    MinuteWait = float(expWaitTime*60)
    return float(MinuteWait)
def display_menu():
    print(' MENU')
    print("1)Calculate wait time")
    print("2)Quit")
    selectmenu = input("Menu choice:")
    return selectmenu
