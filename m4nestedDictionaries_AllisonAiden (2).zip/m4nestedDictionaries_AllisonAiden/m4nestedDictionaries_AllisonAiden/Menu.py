#Aiden Allison
#2/6/2024
#working with dictionarys and lists
from Functions import *
def main():
    student_reg = get_student_reg()
    menu = display_menu()
    while menu != "5":
        print(menu)
        if menu == "1":
            for roster in student_reg:
                print(roster)
        elif menu == "2":
            locate = input("What class roster do you want to find: ")
            for roster in (display_student_ros(student_reg,locate)):
                print(roster)
        elif menu == "3":
            locate = input("What major do you want to find: ")
            for major in (display_student_major(student_reg,locate)):
                print(major)
                print()
                print()
        elif menu == "4":
            locate = input("What ID do you want to find: ")
            for major in display_student_ID(student_reg,locate):
                print(major)
        elif menu == "5":
            print("quitting program....")
        else:
            print("error no number to select menu")
        menu = display_menu()
if __name__ == "__main__":
        main()
