def display_menu():
    print(' MENU')
    print("1)Display student registry")
    print("2)Display student roster")#display all students in a class
    print("3)Display students by major")
    print("4)Display student by ID")
    print("5)Quit")
    selectmenu = input("Menu choice:")
    return selectmenu
def display_student_ros(student_reg,course_class):
    studentsroster = []
    for item in student_reg: #item is actually a dict
                for course in (item["courses"]): # This part is a list
                    if course == course_class:
                        studentsroster.append(item["firstName"] + " " + item["lastName"])     
    return studentsroster
def display_student_major(student_reg,course_class):
    studentsroster = []
    for item in student_reg: #item is actually a dict
        major = item["major"]
        if major == course_class:
            studentsroster.append(item["firstName"] + " " + item["lastName"])
    return studentsroster
def display_student_ID(student_reg,ID):
    studentsroster = []
    for item in student_reg: #item is actually a dict
        if ID == item["stuID"]:
            studentsroster.append(item)
    return studentsroster        
def get_student_reg():
    student_registry= [ {"stuID":"1201", 'firstName':'Sarah', 'lastName':'Spadling', 'major':'Programming', 'courses':["MAT143-Math","ENG111-English","CIS115-Intro to Programming","CSC121-Python"]},

               {"stuID":"1202", 'firstName':'James', 'lastName':'Spalding', 'major':'Psychology', 'courses':["MAT243-Math","ENG211-English","PSY101-Intro to Psychology","ETH101-Intro to Ethics"]},

               {"stuID":"1203", 'firstName':'John', 'lastName':'Spalding', 'major':'Programming', 'courses':["MAT143-Math","ENG111-English","CIS115-Intro to Programming","CSC121-Python"]},

               {"stuID":"1204", 'firstName':'Rayliee', 'lastName':'Craston', 'major':'Biology', 'courses':["MAT143-Math","ENG111-English","BIO101-Intro to Biology","ICE101-Ice Skating"]},

               {"stuID":"1205", 'firstName':'Carter', 'lastName':'Craston', 'major':'Chemistry', 'courses':["MAT343-Math","ENG211-English","ETH101-Intro to Ethics","HIS201-American History"]},

               {"stuID":"1206", 'firstName':'Brodiey', 'lastName':'Craston', 'major':'Physics', 'courses':["MAT143-Math","ENG111-English","PHY101-Intro to Physics","ICE101-Ice Skating"]},

               {"stuID":"1207", 'firstName':'Caera', 'lastName':'Mikkelsen', 'major':'Art History', 'courses':["MAT243-Math","ENG211-English","HIS168-Religious History","HIS190-Intro to Art History"]},

               {"stuID":"1208", 'firstName':'Sophiah', 'lastName':'Mikkelsen', 'major':'Economics', 'courses':["MAT143-Math","ENG111-English","ETH101-Intro to Ethics","BUS121-Market Basics"]},

               {"stuID":"1209", 'firstName':'Scott', 'lastName':'Scott', 'major':'Programming', 'courses':["MAT143-Math","ENG111-English","CIS115-Intro to Programming","CSC121-Python"]},

               {"stuID":"1301", 'firstName':'Sean', 'lastName':'Lean', 'major':'Education', 'courses':["MAT343-Math","ENG311-English","ETH101-Intro to Ethics","EDU201-Adolescent Education"]},

               {"stuID":"1302", 'firstName':'Emily', 'lastName':'Mikkelsen', 'major':'Graphic Design', 'courses':["ART320-Botanical Design","ASB353-Death and Dying","GRA323-Technology for Design","GRA345-Design Rhetoric"]},

               {"stuID":"1303", 'firstName':'Porter', 'lastName':'Parker', 'major':'Psychology', 'courses':["MAT143-Math","ENG111-English","PSY101-Intro to Psychology","ETH101-Intro to Ethics"]},

               {"stuID":"1304", 'firstName':'Crete', 'lastName':'Crate', 'major':'Occult Studies', 'courses':["MAT143-Math","ENG111-English","ETH101-Intro to Ethics","HIS168-Religious History"]},

               {"stuID":"1305", 'firstName':'Parker', 'lastName':'Peter', 'major':'Education', 'courses':["MAT243-Math","ENG211-English","ETH101-Intro to Ethics","EDU201-Adolescent Education"]},

               {"stuID":"1306", 'firstName':'Orhum', 'lastName':'Sorhum', 'major':'Programming', 'courses':["MAT343-Math","ENG211-English","CIS215-Advanced Programming","CSC221-Advanced Python"]},

               {"stuID":"1307", 'firstName':'Durham', 'lastName':'Sorhum', 'major':'Culinary Arts', 'courses':["MAT143-Math","ENG211-English","CUL201-Sous Basics","CUL221-Kitchen Cleaning"]},

               {"stuID":"1308", 'firstName':'Werhum', 'lastName':'Sorhum', 'major':'Business', 'courses':["MAT243-Math","ENG211-English","ETH101-Intro to Ethics","BUS221-Market Practices"]},

               {"stuID":"1309", 'firstName':'Merhum', 'lastName':'Sorhum', 'major':'Politics', 'courses':["MAT243-Math","ENG211-English","ETH101-Intro to Ethics","HIS201-American History"]},

               {"stuID":"1401", 'firstName':'Lerhum', 'lastName':'Sorhum', 'major':'Programming', 'courses':["MAT243-Math","ENG211-English","CIS215-Advanced Programming","CSC221-Advanced Python"]},

               {"stuID":"1402", 'firstName':'Seurem', 'lastName':'Sorhum', 'major':'Engineering', 'courses':["MAT343-Math","ENG211-English","ETH101-Intro to Ethics","EGI321-Mechanical Engineering"]}
               ]
    return student_registry
