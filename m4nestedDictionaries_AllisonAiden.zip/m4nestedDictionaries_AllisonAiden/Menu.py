#Aiden Allison
#2/6/2024
#working with dictionarys and lists
from Functions import *

def main():
    student_registry= [ {"stu_id":"12001", "first_name":"Amiyah", "last_name":"Huffman","major":"Programming",
                     "courses":["CSC121-Python","MAT143-Math","DBA110-Database","NOS110-Networking"] },
                   
                    {"stu_id":"12023", "first_name":"Sawyer", "last_name":"Gonzalez","major":"Networking",
                     "courses":["ENG111-English","MAT143-Math","CIS115-Intro to Programming","CTS120-Hardware & Software Support"]}
                    ]
    display_content(student_registry)
    menu = display_menu()
    while menu != "5":
        print(menu)
        if menu == "1":
            display_content(student_registry)
        elif menu == "2":
            pass
        elif menu == "3":
            pass
        elif menu == "4":
            pass
        elif menu == "5":
            print("quitting program....")
        else:
            print("error no number to select menu")
        menu = display_menu()
if __name__ == "__main__":
        main()
