def display_menu():
    print(' MENU')
    print("1)Display student registry")
    print("2)Display student roster")#display all students in a class
    print("3)Display students by major")
    print("4)Display student by ID")
    print("5)Quit")
    selectmenu = input("Menu choice:")
    return selectmenu
def display_content(student_list):
    for item in student_list:
        for key in item:
            print(key,":",item[key])
        print()
        print()

