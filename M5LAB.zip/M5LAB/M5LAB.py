#Aiden Allison
#2/13/24
#M5LAb - reading data from files


def calcBMI(weight,height):
    BMI = weight/(height ** 2) * 703
    return BMI
def main():
    with open("DATA.txt","r") as f:
        content = f.readlines()
        content = list(map(str.strip,content))
        new_list = []
        for item in content:
            item = item.split(",")
            new_list.append(item)



            
            int_list = []
        for item in new_list[1:]:
            name = item[0]
            var = list(map(int, item[1:]))
            int_list.append([name] + var)
            
        print(int_list)
            
        for item in int_list:
            with open("bmi_output.txt", "a") as o:
                o.write(f"PatientID:{item[0]} BMI:{calcBMI(item[2],item[1]):.2f} \n")
if __name__ == "__main__":
    main()
