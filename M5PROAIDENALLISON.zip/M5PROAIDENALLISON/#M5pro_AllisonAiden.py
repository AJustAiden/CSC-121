#Aiden Allison
#2/15/24
#M5pro - CVS files
import csv

def display_menu():
    print(' MENU')
    print("1)Read from existing list of transactions")
    print("2)Add new transactions to file")
    print("3)Display Total Sales for each Product")
    print("4)Display Total Units and Total Sales for each Customer")
    print("5)Quit")
    selectmenu = input("Menu choice:")
    return selectmenu
def Totalamount(unit_list,prodID):
    temp_list = []
    count = 0
    for i in unit_list:
        temp_list.append("ProdID")
        temp_list.append(prodID[count])
        temp_list.append("Amount of sales made:")
        temp_list.append(i)
        count = count + 1
    print(temp_list)
def Totalsales(unit_list,price_list,custID):
    temp_list = []
    count = 0
    for i in unit_list:
        temp_list.append("custID")
        temp_list.append(custID[count])
        temp_list.append("Amount of money spent:")
        temp_list.append(i * price_list[count])
        count = count + 1
    print(temp_list)
    f = open("myfile.txt", "w")
    myfile.write(temp_list)
def addcvs(numberlist):
    add_list = []
    add_list.append(len(numberlist)+1)
    add_list.append(input("date:"))
    add_list.append(input("prodID:"))
    add_list.append(input("custID:"))
    add_list.append(input("units sold:"))
    add_list.append(input("price:"))
    return add_list
def main():
    with open('sales.csv', mode ='r')as f:
        cvsf = csv.DictReader(f)
        content = cvsf
        number_list = []
        unit_list = []
        price_list = []
        prodID_list = []
        custID_list = []
        date_list = []
        display_list =[]
        for col in content:
            number = (col["#"])
            number_list.append(number)
            
            
            date = (col["date"])
            date_list.append(date)


            prodID = (col["prodID"])
            prodID_list.append(prodID)

            
            custID = int(col["custID"])
            custID_list.append(custID)

            
            units = int(col["units"])
            unit_list.append(units)

            
            price = float(col["price"])
            price_list.append(price)
            
            display_list.append(number)
            display_list.append(date)
            display_list.append(prodID)
            display_list.append(custID)
            display_list.append(units)
            display_list.append(price)
        menu = display_menu()
        while menu != "5":
            print(menu)
            if menu == "1":
                print(display_list)
            elif menu == "2":
                add_list = addcvs(number_list)
                for i in add_list:
                    f.write(str(i))
            elif menu == "3":
                Totalamount(unit_list,prodID_list)
            elif menu == "4":
                Totalsales(unit_list,price_list,custID_list)
            elif menu == "5":
                print("quitting program....")
            else:
                print("error no number to select menu")
            menu = display_menu()

if __name__ == "__main__":
    main()
